# PIPELINE_STATE — nefu-student-handbook

> 断点续跑用。**每完成一个阶段即更新本文件。**
> 本轮重建时间：2026-10-09（语料变更触发全量重蒸）

## 本轮触发原因

用户于 2026-10-09 17:45 重新打包 rar。逐文件 MD5 比对：26 份原始文本中
**仅 `本科生综合素质考评管理办法.docx` 为新文件**（今日 17:44），
其余 25 份与 2026-10-06 一致。

上轮（10-06）已完整交付并安装 8 个入口，但**发现其`07` 相关断言与新语料不符**
（详见 `sources/ERRATA.md` E1/E2/E3），故用户裁定**全量重新蒸馏**。

## 语料状态

-来源：`C:/Users/FFFAN/Desktop/东北林业大学学生手册/东北林业大学学生手册全部.rar`
- 解包：主 rar → 总则.rar → {德育学分实施办法.rar, 学生管理规定与行为准则.rar}（三层）
- 装配：20 份 / 120,619 字符（L1 4 / L2 8 / L3 7 / L4 1）
- 块索引：438 elements → **186 chunks**，FTS5 bigram 已建（`.cangjie/index/lexical.sqlite`）

## 阶段进度

| 阶段 | 名称 | 状态 | 产出 |
|---|---|---|---|
| 准备 | 语料重建 + ERRATA | ✅ | `sources/`、`sources/ERRATA.md`、`tools/*` |
| 0 | Adler 整书理解 | ✅ | `BOOK_OVERVIEW.md` |
| 1 | 5 extractor 并行提取 | ⏳ | `candidates/` |
| 1.5 | 三重验证 | ⏳ | `verified.md`、`rejected/` |
| 1.6 | 晋级门 | ⏳ | `.cangjie/capabilities/destinations.json` |
| 2 | RIA++ 能力卡 | ⏳ | `.cangjie/capabilities/cards/` + `verified.yaml` |
| 3 | Zettelkasten 链接 | ⏳ | `GLOSSARY.md`、also_read |
| 4 | 压力测试 | ⏳ | `eval/` |
| 5 | 编译交付 | ⏳ | `dist/`、`DIGEST.md`、安装 |

## 本轮必须修正的已知错误（上轮遗留）

| 位置 | 错误断言 | 正确事实 |
|---|---|---|
| `honors-evaluation` | 五维 德10/智70/体10/美育5/劳育5 | **四维** 思德20/专业文化65/身体心理10/其它5（`07` 第四条） |
| `honors-evaluation` | 综测「优秀≥90」是校级评优门票（`07` 第三十八条） | `07` 仅 22 条、**无等级制**、无此条；门票应引 `06` 的**位次**要求 |
| `exam-misconduct` | 综测扣分 警告/严警/记过/留校察 =5/10/15/20（第十一条） | 实为**警告减20、严重警告减30**（第十条校规校纪1项）；记过/留校察看无独立档位 |
| `integrity-conduct` | 德育占 10% | 思想道德素质占 **20%** |
| `glossary.md` g06 | 同上三项 | 同上 |
| `ce56` 反例 | 「误用 `90` 的四维会算出更高分」 | **方向颠倒**：`90` 四维与官方一致，错的是虚构的五维 |

## 环境经验

- RAR5 双层解包：`C:/Windows/System32/tar.exe -xf <rar> -C <dir>`（Git Bash 的 GNU tar 不可用）
- python：`C:/Users/FFFAN/.workbuddy/binaries/python/envs/default/Scripts/python.exe`（已装 pyyaml/olefile/pypdf）
- `build_chunks.py` **单文件模式会互相覆盖** `chunks.jsonl` → 必须先合并为 `corpus.md` 再单次调用
- `docx` 提取必须剥离 `<w:tbl>`（见 `tools/docx_extract.py`），否则属性 XML 泄漏进正文