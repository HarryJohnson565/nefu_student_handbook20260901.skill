import json, io
from collections import Counter

P = "promote"; R = "route"; X = "reject"
U = {}
def add(i, slug, name, dest, g, reason, decision=None):
    U[i] = dict(id=i, slug=slug, name=name,
                gate=dict(zip(["G1","G2","G3","G4","G5"], g)),
                decision=decision or P, destination=dest, reason=reason)

# ============ academic-status ============
add("f01","credit-warning-dismissal","学业预警与退学判定","academic-status",(1,1,1,1,1),
    "4 条条文分列第三十七/三十八/三十九条，实体面自足；与 f03 程序面依据零重叠。须修正边界对 f03 的错误指向并删除「等级」二字。")
add("f02","study-length-extension","最长学习年限、延长学习年限与提前毕业判定","academic-status",(1,1,1,1,1),
    "6 条连续条文构成「含/不含年限」的差异计算，两条方向相反无法靠常识推断。吸收 f13（毕业出口）后为学籍纵向轴宿主。")
add("f03","dismissal-procedure-service","退学处理决定的程序与送达","academic-status",(1,1,1,1,1),
    "跨文件（02+09）程序链条，且是全语料「送达阶梯」的唯一 owner。承接被拒单元 f60 的送达内容后无同题竞争者。")
add("f04","leave-of-absence","休学准予与复学判定","academic-status",(1,1,1,1,1),
    "条件—程序—待遇—复学四段完整，复学一周内逾期→退学为真实跨条迁移。吸收淘汰单元 f05 后契约完整。")
add("f06","major-transfer-eligibility","转专业资格与准入条件判定","academic-status",(1,1,1,1,1),
    "含反常识规则（不设成绩门槛）与第六条→第七条两级附加条件推理。独立于 f07（判资格 vs 判录取）。")
add("f07","major-transfer-procedure","转专业志愿与考核录取程序","academic-status",(1,1,1,1,1),
    "把 40% 权重上限转成「一份具体考核方案是否合规」的可判定工具，问题空间与 f06 不重叠。")
add("f08","school-transfer-prohibition","转学禁止情形判定","academic-status",(1,1,1,1,1),
    "实体要件与程序要件分离，可对未列举的新事实作可判定结论。")
add("f25","dismissal-execution-records","开除学籍的离校执行与档案处理","academic-status",(1,1,1,1,1),
    "与 f03 的退学路径构成双证书对照（写实性学习证明 vs 退学证明+肆业证书），是差异化知识而非重复。")
add("f62","innovation-enterprise-credit","创新创业学分的认定范围、计分与封顶","academic-status",(1,1,1,1,1),
    "★必须保留与 f34 的两体系不可折算声明（8 学分 vs 每学期 6/在校 15）——这是 07 换版后最易错处。")
add("f63","competition-classification-and-violation","学科竞赛分类、等级认定与违规处理","academic-status",(1,1,1,1,1),
    "等级认定 ≠ 学分认定（f62），职责相邻但不重叠；四类划分+等级映射为本校独有。")

# ============ course-credit ============
add("f09","retake-remedial-deferred-routing","补考 / 重修 / 缓考三通道分流","course-credit",(1,1,1,1,1),
    "三通道宿主，吸收 f10/f11 后为唯一入口。触发边界须写明：问「走哪条路/上限多少」用本单元，问「为什么不能补考」已被吸收。")
add("f14","exchange-credit-transfer","交换生学分转换与成绩记载","course-credit",(1,1,1,1,0),
    "三层转换规则（相近/不同 × 先必修后选修）结构化。G5 判否仅因需与 f09 区分校内外来源，不构成 G1/G2/G3 失败。")

# ============ exam-misconduct ============
add("f15","course-exam-violation-vs-cheating","课程考试违纪 vs 作弊的定性分流","exam-misconduct",(1,1,1,1,1),
    "携带/使用分界的唯一 owner，四层中的第 2 层。必须携带 N18 边界：留校察看仅适用 03 第十五条一般作弊，组织作弊属第九条开除。")
add("f16","four-layer-consequence","同一作弊/违纪行为的四层口径并列","exam-misconduct",(1,1,1,1,1),
    "四层并列的唯一 owner，独立于 f15 的单层定性。第 2 层须回指 f15 不复述，否则两单元争抢同一层。")
add("f20","serious-cheating-dismissal","开除学籍的八类情形判定","exam-misconduct",(1,1,1,1,1),
    "开除触发的唯一 owner，与 f21（学术切面深度）为不同问题空间。含 X4「兜底不及于开除档」的限制。")
add("f21","academic-misconduct-sanction","学术不端与伪造学术材料处分判定","exam-misconduct",(1,1,1,1,1),
    "回答 f20 不答的问题（未达情节严重时的层级），并正确切分「情节严重的」修饰范围，非重复。")

# ============ discipline-appeal ============
add("f17","sanction-five-tiers","纪律处分五档与期限","discipline-appeal",(1,1,1,1,1),
    "档位表唯一 owner；「以上含本数」是解读全校 20 余处「以上」的钥匙。步骤 7 须携带 X4 兜底限制。")
add("f19","absence-sanction-ladder","旷课累计的处分阶梯","discipline-appeal",(1,1,1,1,1),
    "输入为学时数（与 f17 的行为类型不重叠），含反直觉的「处分不累加、以等级高者为准」。须补注 80 学时出自 03:174 括注。")
add("f23","dormitory-violation-sanction","违反住宿管理规定的处分阶梯","discipline-appeal",(1,1,1,1,1),
    "住宿违规→处分的专门阶梯，与 f19（同为阶梯但行为域不同）不争抢。须补 B01 夜不归宿「须人工裁量」声明。")
add("f24","unlisted-violation-fallback","未列举违纪行为的兜底处置与处分决定书要素","discipline-appeal",(1,1,1,1,1),
    "兜底与决定书要素的唯一 owner，「瑕疵≠效力待定」为独立推论。须删「校长办公会级别的实质把关」这一无据表述。")
add("f57","appeal-acceptance-window","校内申诉的受理条件与时限链","discipline-appeal",(1,1,1,1,1),
    "申诉「准入」唯一 owner，与 f58「受理后怎么判」分界清晰。3 日补正视为放弃、撤回后同一事由不可再诉为独立知识。")
add("f58","appeal-review-conclusion","申诉复查的程序与四类结论","discipline-appeal",(1,1,1,1,1),
    "申诉「过程与结论」唯一 owner；「只有维持可自决、其余三类须上校长办公会」为权限分层；承接 f60 的 60 日公告期。")

# ============ integrity-conduct ============
add("f26","integrity-abc-classification","学生诚信档案失信记录的 A/B/C 级认定","integrity-conduct",(1,1,1,1,1),
    "A 级集合 ⇔ 第九条开除情形集合，是 f15/f20 后果分层（N18）的判据来源。与 f17 处分轨道分离且不合并。")
add("f27","integrity-retention-clearing","失信记录的时效期、自动清除与预警分级","integrity-conduct",(1,1,1,1,1),
    "「处分解除 ≠ 失信清除」只能由本单元表达，是它与 f26 必须分立的判决性证据。与 f17 零数字重叠。")
add("f29","conduct-grade-four-levels","操行评等四级评定","integrity-conduct",(1,1,1,1,1),
    "30-40% 硬比例上限 + 八步评定程序的唯一 owner。吸收 f30 后「评等」与「折分」不再分裂。")
add("f31","moral-credit-award","德育学分的取得与记过处分的归零效应","integrity-conduct",(1,1,1,1,1),
    "记过→0分→重修→毕业资格四级传导，吸收 f32 后闭环完整。须补列 08 第七、十条为依据。")
add("f33","moral-credit-objection-appeal","德育成绩的异议与复议时限链","integrity-conduct",(1,1,1,1,1),
    "两级通道顺序固定 + 最长 17 工作日可算。吸收 f28 后成为「记载/成绩异议与复议时限链」宿主。")
add("f34","comprehensive-eval-formula","综合素质考评的四维加权总分与结果用途","integrity-conduct",(1,1,1,1,1),
    "ERRATA E1/E2 最严格执行者，负向预测「89 分无制度后果」不可替代。必须携带 B05：综测无等级门槛 ≠ 无位次门槛。")
add("f35","cadre-duty-score","综测「其它」维度的学生干部职务分折算","integrity-conduct",(1,1,1,1,1),
    "f34 不回答职务分表与五级换算，故问题空间不重叠；16 个数据格自足。须把三/五日时限从第二十一条改到第二十条。")

# ============ honors-evaluation ============
add("f36","honors-prerequisite-veto","评优的前置否决项与基本条件","honors-evaluation",(1,1,1,1,1),
    "f37-f40 的共同上位框架，本身可独立回答「谁一票否决」。编译要求：下游单元须各自复述基本条件，不得运行时依赖本单元。")
add("f37","three-good-student","三好学生评选条件与比例","honors-evaluation",(1,1,1,1,1),
    "答案 = 85 分整计入 + 比例基数学生总数 10%。与 f38 的对照（75 分 / 干部总数基数）即其鉴别性价值来源。")
add("f38","excellent-student-cadre","优秀学生干部评选条件与比例","honors-evaluation",(1,1,1,1,1),
    "与 f37 构成对照而非重复：门槛差 85/75、基数差 学生总数/干部总数。已正确以 03 覆盖 90 的 7%（N3）。")
add("f39","excellent-graduate","优秀毕业生评选条件与撤销","honors-evaluation",(1,1,1,1,1),
    "撤销出口唯一 owner，「已解除亦撤销」宽于 f36 否决项这一非显然推论不可替代。")
add("f41","advanced-class-collective","先进班集体评选条件与六项否决","honors-evaluation",(1,1,1,1,1),
    "集体维度（双前 30%、五星级寝室、人数≤10 排除）与个人维度差异过大，独立成卡。")
add("f42","honors-procedure-and-objection","评优的申报、公示与异议时限链","honors-evaluation",(1,1,1,1,0),
    "程序面唯一 owner，实名异议 + 学工部受理是鉴别性知识。G5 判否因「公示几天」与 f43 触发词重叠，须靠体系消歧词构造评测集。")
add("f43","excellent-student-scholarship","优秀学生奖学金分档、比例与降等","honors-evaluation",(1,1,1,1,0),
    "分档/比例/金额唯一 owner，「降等≠取消、缓发≠取消」两处易错方向正确。与 f42 分属不同体系（公示 3 天 vs 3 个工作日，X1）。")
add("f46","league-breakthrough-and-ratio","团内评优的破格条件与评选比例","honors-evaluation",(1,1,1,1,1),
    "破格通道唯一 owner，须与 f45 合并后成 06 团内评优完整入口。须与 f36 的 03 体系分清并携带 N17 并列要求。")
add("f47","league-branch-and-league","五四红旗团支部与五四红旗团委的评选条件","honors-evaluation",(1,1,1,1,1),
    "集体荣誉（团支部/团委）≠ f41（班级）；边界对「全年度无成员受警告以上处分」的文义自我闭合分析准确。")
add("f48","youth-may-fourth-medal-and-top-ten","青年五四奖章与十佳大学生评选条件","honors-evaluation",(1,1,1,1,1),
    "校团委路径，与 f39 学工部路径经边界④显式区分（本批质量最高的边界）；「各学期操行均优」措辞区别于 f50 的「学年度」。")

# ============ financial-aid ============
add("f44","scholarship-exclusivity-matrix","各类奖学金/助学金的兼得互斥矩阵","financial-aid",(1,1,1,1,1),
    "跨 5 份细则同位条文互证，提供可执行组合决策树；回答 f43/f50/f51 都不答的「能不能同时拿」。")
add("f49","hardship-determination-tiers","家庭经济困难学生的三档认定","financial-aid",(1,1,1,1,1),
    "认定环节唯一 owner；「参考条件非充分条件」+ 常态化复核 + 一卡通双刃剑三条洞见独立成立。")
add("f50","national-scholarship","国家奖学金的资格门槛与前 30% 例外通道","financial-aid",(1,1,1,1,1),
    "「有排名」侧标杆（双前 10% + 前 30% 例外通道）。必须保留「综合考评成绩排名 ≠ 综测≥90」的 E2 防线。")
add("f51","inspirational-scholarship","国家励志奖学金资格门槛","financial-aid",(1,1,1,1,1),
    "「无排名」侧，与 f50 的门槛差异本身即独立意图；互斥关系由 f44 承载而非本单元。")
add("f52","national-grant","国家助学金资格门槛与破格通道","financial-aid",(1,1,1,1,1),
    "「原则上无不及格」为软约束，区别于 f50 硬表述，构成三者中最有鉴别力的对照。")
add("f53","grant-suspension","奖助学金的中止/延迟发放情形","financial-aid",(1,1,1,1,1),
    "发放环节独立契约（资格环节在 f49-f52），休学/退学/转专业/参军情境具备真实预测力。")
add("f54","campus-student-loan","校园地国家助学贷款的申请、额度与还款链","financial-aid",(1,1,1,1,1),
    "学制+15 年、最长 22 年封顶为独有算式。必须与 f56 互设排除条款（X3/B08）：数额相同但借款需还 vs 补偿免还。")
add("f55","work-study","勤工助学的资格、岗位类型与工时限制","financial-aid",(1,1,1,1,1),
    "280 元/月 + 14 元/小时双轨计酬自足，并正确引入「可适当上下浮动」的非绝对性。")
add("f56","military-service-and-rural-employment-support","服兵役资助与基层就业学费补偿/贷款代偿","financial-aid",(1,1,1,1,1),
    "违约后果链完整（取消资格→停补→还贷→重签→严重违约→征信）。与 f54 的区分是编译硬约束。")

# ============ 被拒绝（晋级门新增） ============
add("f10","makeup-eligibility","补考资格否决判定",None,(1,0,0,1,1),
    "G-2/G-3 不通过：「什么情况不能参加补考」已被 f09 的分流决策树完整包含——f09 步骤 1 与本单元步骤 1 逐字重复「体育/考查课/通识选修/实习实践不安排补考」。独立成卡会与 f09 争抢同一问题空间并给出重复答案；G-3 亦不通过，因其三项否决须复述 f09 的课程范围前提才能执行。内容并入 f09（M2）。",
    decision=X)
add("f11","deferred-exam-approval","缓考资格、审批时限与材料核验",None,(1,0,0,1,1),
    "G-2/G-3 不通过：缓考的课程范围与事由（第十条）已由 f09 步骤 4 承载，且 f11 步骤 3 复述「与补考课程一致」；其最关键推导「缓考试卷=补考试卷故上限随通道而变（65/75）」只在 f09 的通道语境下成立。独立成卡迫使使用者自行重建 f09 上下文。内容并入 f09（M2）。",
    decision=X)
add("f18","mitigation-aggravation","从轻与从重情节判定",None,(0,1,0,1,1),
    "G-1 不通过：其唯一提问「能不能轻一点」必须先有 f17 的档位才存在，自身无独立输入，无法独立回答任一用户问题。G-3 不通过：V3 弱通过（清单属本校但零数值），输出全为裁量区间，判据依赖 f17 的档位空间。虽内容有价值（否定式预测 + 第九条无降档空间），但按规则不得为凑数强行合并，仅在 M4 记录由 f17 承载裁量提示。",
    decision=X)
add("f60","announcement-service-and-archive","处分/退学决定的送达方式与档案归集",None,(1,0,0,1,1),
    "G-2 不通过（高风险单元的诚实处置）：其「解决的问题」与 f03 完全重叠——f03 自述「人不在学校怎么办？」、本单元自述「人不在学校、拒绝签收，决定怎么送达？」，两者引用同一条 02:104 与 03:267 的送达阶梯，会给出两份措辞不同的答案。更关键的是其最有价值的结论「送达方式直接决定申诉权起算点」必须同时引用 f57 的 10 日与 f58 的 60 日才成立，无法不引用其它单元内部实现而独立执行（G-3 亦不通过）。内容并入 f03（送达阶梯）与 f58（60 日公告期），M9。",
    decision=X)

# ============ 路由入口 ============
add("f61","dormitory-fire-and-safety-redline","宿舍消防安全红线与违规电器判定","nefu-student-handbook",(1,1,1,1,1),
    "降级单元修正（「十一类」→「十二类」）后晋级。宿舍红线是跨 skill 的公共前置（f23 处分阶梯的下游），独立成 skill 会造成两份红线，故路由到入口 skill 统一供给。", decision=R)
add("f64","student-rights-duties-and-appeal-body","学生权利义务与申诉委员会（《章程》口径）","nefu-student-handbook",(1,1,1,1,1),
    "降级单元修正（第五章→第六章第三十二条）后晋级。它是入口 skill 的路由依据本体（09 第二/三章 0 字节 → 《章程》第十六、十七条），必须位于入口而非任一子域。", decision=R)

order = ["f01","f02","f03","f04","f06","f07","f08","f25","f62","f63",
         "f09","f14",
         "f15","f16","f20","f21",
         "f17","f19","f23","f24","f57","f58",
         "f26","f27","f29","f31","f33","f34","f35",
         "f36","f37","f38","f39","f41","f42","f43","f46","f47","f48",
         "f44","f49","f50","f51","f52","f53","f54","f55","f56",
         "f61","f64",
         "f10","f11","f18","f60"]
units = [U[i] for i in order]
assert len(units) == 54 and len({u["id"] for u in units}) == 54, len(units)

expected = set(("f01 f02 f03 f04 f06 f07 f08 f09 f10 f11 f14 f15 f16 f17 f18 f19 f20 f21 "
                "f23 f24 f25 f26 f27 f29 f31 f33 f34 f35 f36 f37 f38 f39 f41 f42 f43 f44 "
                "f46 f47 f48 f49 f50 f51 f52 f53 f54 f55 f56 f57 f58 f62 f63").split())
# 晋级门受评集 = verified.md 的 51 条通过单元 + 3 条仍具晋级价值的降级单元
#   f60（G-2/G-3 不通过 -> reject）、f61 / f64（修正后 -> route 到入口 skill）
gate_set = expected | {"f60", "f61", "f64"}
assert {u["id"] for u in units} == gate_set, ("受评集不一致", sorted(gate_set ^ {u["id"] for u in units}))

n_promote = sum(1 for u in units if u["decision"] == "promote")
n_route = sum(1 for u in units if u["decision"] == "route")
n_reject_units = sum(1 for u in units if u["decision"] == "reject")
ledger = {}
for u in units:
    if u["destination"]:
        assert u["destination"] not in ledger or True
        ledger.setdefault(u["destination"], []).append(u["id"])
# 每个 active 能力恰好一个去向
for dest, ids in ledger.items():
    assert len(ids) == len(set(ids)), dest
flat = [i for ids in ledger.values() for i in ids]
# 54 条受评单元 - 4 条 reject = 50 个 active 能力，每个恰好一个去向
assert len(flat) == len(set(flat)) == 50, (len(flat), len(set(flat)))
# G-1/G-2/G-3 与 G4/G5 规则校验
for u in units:
    g = u["gate"]
    hard = g["G1"] and g["G2"] and g["G3"]
    soft = g["G4"] or g["G5"]
    if u["decision"] == "reject":
        assert not (hard and soft), u["id"]
    else:
        assert hard and soft, u["id"]

out = {
  "generated_at": "2026-10-09",
  "stage": "1.6 晋级门评审",
  "input": "candidates/verified.md（阶段 1.5 正式结论）",
  "corpus": {"files": 20, "chars": 120619, "chunks": 186},
  "candidate_pool": 566,
  "framework_total": 64,
  "verification_summary": {
    "note": "任务简报给出「通过 49」，与三份报告自身的编号清单矛盾；按逐条判定与编号清单实计为 51（f01-f22 十八条 + f23-f44 十八条 + f45-f64 十五条）。校验和 51+12+1=64 闭合。详见 verified.md §0.2。",
    "pass": 51, "downgrade": 12, "eliminated": 1
  },
  "gate_rule": "G1&G2&G3 必过；G4/G5 至少一条",
  "gate_outcome": {"promote": n_promote, "route": n_route, "reject": n_reject_units + 1,
                   "note": "reject 含阶段 1.5 已淘汰的 f05；晋级门新增拒绝 f10、f11、f18、f60"},
  "destination_ledger": ledger,
  "units": units,
  "rejected": [
    {"id":"f05","slug":"leave-no-assessment","stage":"1.5",
     "reason":"淘汰：零本校特异性的教育部令 41 号通用条款 + 自身边界承认核心问题须人工裁量 + 与 f04 完全重叠。内容并入 f04（M1）。"}
  ] + [{"id":u["id"],"slug":u["slug"],"stage":"1.6","reason":u["reason"]}
       for u in units if u["decision"] == "reject"],
  "merge_proposals": [
    {"members":["f05"],"host":"f04","reason":"淘汰单元内容并入休学单元的「期间待遇与考核」子节；退学出口并入 f01 第三十八条（三）。f04 边界须加注「复学后已修学分与成绩归属：语料未规定，须人工裁量」。"},
    {"members":["f10","f11"],"host":"f09","reason":"三通道合为一个决策树：先判课程范围（第三条）→ 再判通道资格（第四条）→ 再判审批与时限（第十—十六条）。f10 的 30 分括注反向推理与 f11 的「材料造假升级为考试作弊」两条高价值结论完整保留。"},
    {"members":["f13"],"host":"f02","reason":"「学制年限与毕业出口」合并为纵向轴一单元；删除 f13 边界关于第五十条残缺与序号不连续的两句，并补列第三十九条第（三）项为依据。"},
    {"members":["f18"],"host":"f17","reason":"仅为记录在案的建议，不构成晋级门依据（f18 已判 reject）。从轻/从重只作用于 f17 确定的档位，宜作为 f17 的裁量提示段而非独立单元。"},
    {"members":["f28"],"host":"f33","reason":"同为「公示/记录→异议→复查→时限」模板的两次实例化；合并后生成 5 个工作日 / 3+7+10 工作日 / 四条互斥通道的完整对照表。同时修正 f28 的两处交叉引用指错。"},
    {"members":["f30"],"host":"f34","reason":"f30 是 07 第四条「其它」维度的输入查表项（优30/良20/中10/差0 × 5%），单独成卡会与 f34 争夺「其它维度」所有权，且其唯一结论 1.5 分无判定价值。"},
    {"members":["f32"],"host":"f31","reason":"「60 分门槛→记过归零→义工重修」为单一闭环；合并时必须补入 07 第八条第（一）项 7「不含因德育学分重修参加的义工」的互斥规定。"},
    {"members":["f40"],"host":"f36","reason":"军训先进人是 f36 的对象特殊分支（评选对象为参训新生），仅补 3% / 不足 1 人按 1 人 / 补训不计入 / 党委武装部公示四条。"},
    {"members":["f45","f46"],"host":"f46","reason":"常规通道与破格通道合并为 06 团内评优完整入口（原「互斥契约须靠切分维持」的顾虑由此解除）。合并时必须删除 f45 边界②对限定语的扩大解释（N17）。"},
    {"members":["f60"],"host":"f03","reason":"送达阶梯并入 f03，60 日复查决定书公告期并入 f58，建立「申诉期起算点单点维护」以免两处漂移（修正项 A24）。"},
  ]
}

path = r"c:\Users\FFFAN\WorkBuddy\2026-10-06-19-01-31\books\nefu-student-handbook\candidates\destinations.json"
with io.open(path, "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print("OK ->", path)
print("promote=%d route=%d reject=%d (含 f05)" % (n_promote, n_route, n_reject_units+1))
print("ledger:", {k: len(v) for k, v in sorted(ledger.items())})