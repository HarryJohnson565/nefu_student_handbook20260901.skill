# -*- coding: utf-8 -*-
"""阶段 3 报告数据：解析 cards/*.md 的 Also 段，统计链接分布/孤立卡/枢纽卡/易混淆组。"""
import json, os, re, glob, sys
from collections import Counter, defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
dest = json.load(open(os.path.join(ROOT, 'candidates', 'destinations.json'), encoding='utf-8'))
units = {u['id']: u for u in dest['units'] if u.get('destination')}

ROW = re.compile(r'^\|\s*(前置|后继|并列|对照|易混淆)\s*\|\s*(f\d\d)\s*`([^`]+)`\s*\|\s*(.+?)\s*\|\s*$', re.M)

out_deg = {}
in_deg = Counter()
edges = []
rel_by_pair = defaultdict(set)
bad = []

for p in sorted(glob.glob(os.path.join(ROOT, 'cards', '*.md'))):
    t = open(p, encoding='utf-8').read()
    cid = re.search(r'(?m)^id: (f\d\d)', t).group(1)
    m = re.search(r'(?ms)^## Also \| Zettelkasten 链接\n\n(.*)$', t)
    if not m:
        bad.append(f'{cid}: 无 Also 段'); continue
    rows = ROW.findall(m.group(1))
    out_deg[cid] = len(rows)
    if not (2 <= len(rows) <= 5):
        bad.append(f'{cid}: 链接数 {len(rows)} 越界')
    for rel, tgt, slug, why in rows:
        if tgt not in units:
            bad.append(f'{cid}: 目标 {tgt} 非active 单元')
        if tgt == cid:
            bad.append(f'{cid}: 自链接')
        if slug != units[tgt]['slug']:
            bad.append(f'{cid}: {tgt} slug 不符（{slug} vs {units[tgt]["slug"]}）')
        if len(why.strip()) < 15:
            bad.append(f'{cid}->{tgt}: 理由过短')
        in_deg[tgt] += 1
        edges.append((cid, tgt, rel))
        rel_by_pair[frozenset((cid, tgt))].add(rel)

allids = set(units)
isolated = sorted(i for i in allids if out_deg.get(i, 0) == 0 and in_deg[i] == 0)
no_out = sorted(i for i in allids if out_deg.get(i, 0) == 0)
no_in = sorted(i for i in allids if in_deg[i] == 0)
hubs = sorted((i, c) for i, c in in_deg.items() if c >= 5)

print('== 链接总数', len(edges))
print('== 分布')
for i in sorted(allids, key=lambda x: -out_deg.get(x, 0)):
    print(f'  {i} out={out_deg.get(i,0)} in={in_deg[i]}  {units[i]["name"]}')
print('== 孤立卡(无进无出)', isolated)
print('== 无出链', no_out)
print('== 无入链', no_in)
print('== 枢纽卡(入>=5)', hubs)
print('== 关系分布', Counter(r for _, _, r in edges))
print('== 双向互链对', sum(1 for k, v in rel_by_pair.items() if len(v) and len(k) == 2))
print('== 问题', bad if bad else '无')
json.dump({'edges': edges, 'out': out_deg, 'in': dict(in_deg)}, open(os.path.join(ROOT, 'candidates', 'link-graph.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)