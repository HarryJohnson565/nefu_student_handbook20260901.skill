# -*- coding: utf-8 -*-
"""阶段 3 交付校验：GLOSSARY.md 的卡 id 与 Also 段链接 id 是否都在 51 个 active 单元中。"""
import json, os, re, glob, sys
from collections import Counter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8')

dest = json.load(open(os.path.join(ROOT, 'candidates', 'destinations.json'), encoding='utf-8'))
units = {u['id']: u for u in dest['units'] if u.get('destination')}
slugs = {u['slug'] for u in units.values()}
ACTIVE = set(units)

fail = []

# --- 1. Also 段 ---
ROW = re.compile(r'^\|\s*(前置|后继|并列|对照|易混淆)\s*\|\s*(f\d\d)\s*`([^`]+)`\s*\|\s*(.+?)\s*\|\s*$', re.M)
edge_total = 0
rel_cnt = Counter()
cards = sorted(glob.glob(os.path.join(ROOT, 'cards', '*.md')))
if len(cards) != 51:
    fail.append(f'卡片数 {len(cards)} != 51')

for p in cards:
    t = open(p, encoding='utf-8').read()
    name = os.path.basename(p)
    cid = re.search(r'(?m)^id: (f\d\d)', t).group(1)
    secs = re.findall(r'(?m)^## ', t)
    if len(secs) != 7:
        fail.append(f'{name}: 7 段结构异常，实为 {len(secs)} 段')
    m = re.search(r'(?ms)^## Also \| Zettelkasten 链接\n\n(.*)$', t)
    if not m:
        fail.append(f'{name}: 缺 Also 段'); continue
    rows = ROW.findall(m.group(1))
    if not 2 <= len(rows) <= 5:
        fail.append(f'{name}: 链接数 {len(rows)} 不在 2-5')
    seen = set()
    for rel, tgt, slug, why in rows:
        edge_total += 1
        rel_cnt[rel] += 1
        if tgt not in ACTIVE:
            fail.append(f'{name}: 链接目标 {tgt} 非 active 单元')
        elif slug != units[tgt]['slug']:
            fail.append(f'{name}: {tgt} slug 错误（{slug} vs {units[tgt]["slug"]}）')
        if tgt == cid:
            fail.append(f'{name}: 自链接')
        if tgt in seen:
            fail.append(f'{name}: 重复链接 {tgt}')
        seen.add(tgt)
        if len(why.strip()) < 15:
            fail.append(f'{name}->{tgt}: 理由过短')
        for w in ('相关', '有关', '详见', '参见'):
            if why.strip() == w:
                fail.append(f'{name}->{tgt}: 空泛理由「{w}」')

# --- 2. GLOSSARY ---
g = open(os.path.join(ROOT, 'GLOSSARY.md'), encoding='utf-8').read()
gids = set(re.findall(r'\b(f\d\d)\b', g))
bad = sorted(gids - ACTIVE)
if bad:
    fail.append(f'GLOSSARY 引用非 active 卡 id: {bad}')
# 术语表行数
term_rows = [l for l in g.splitlines() if re.match(r'^\|[^-].*\|.*\|.*\|.*\|$', l)]
terms = [l for l in term_rows if not l.startswith('| 术语') and not l.startswith('| 不得')]
# 首次出现的卡 列（第2列）
firsts = []
for l in g.splitlines():
    if l.startswith('| ') and not l.startswith('|---') and not l.startswith('| 术语') and not l.startswith('| 不得'):
        cols = [c.strip() for c in l.strip('|').split('|')]
        if len(cols) >= 4 and re.fullmatch(r'f\d\d', cols[1]):
            firsts.append((cols[0], cols[1]))
badf = sorted({c for _, c in firsts if c not in ACTIVE})
if badf:
    fail.append(f'GLOSSARY「首次出现的卡」列非法 id: {badf}')
# 定义长度 <=40 字
for l in g.splitlines():
    if l.startswith('| ') and not l.startswith('|---'):
        cols = [c.strip() for c in l.strip('|').split('|')]
        if len(cols) >= 4 and re.fullmatch(r'f\d\d', cols[1]):
            d = cols[2]
            if len(d) > 44:
                fail.append(f'GLOSSARY 术语「{cols[0]}」定义 {len(d)} 字，超 40 字上限')
print(f'术语条数: {len(firsts)}')
print(f'Also 段链接总数: {edge_total}')
print('关系分布:', dict(rel_cnt))
print(f'GLOSSARY 出现的卡 id 数: {len(gids)}，全部合法: {not (gids - ACTIVE)}')
print(f'卡片数: {len(cards)}，每卡 7 段: {fail==[] or not any("段" in f for f in fail)}')
print('---')
if fail:
    print('校验失败:')
    for f in fail:
        print('  ✗', f)
else:
    print('✓ 全部校验通过：Also 段链接与 GLOSSARY 引用的卡 id 均在 51 个 active 单元内')