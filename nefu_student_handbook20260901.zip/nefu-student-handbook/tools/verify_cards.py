#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""引用逐字核对 + 关键数字 grep。用法: python verify_cards.py cards/<file>.md"""
import sys, re, glob, os
SRC = os.path.join(os.path.dirname(__file__), '..', 'sources')
FILES = {
    '01': '01-德育管理-操行评等与诚信档案.txt', '02': '02-学业管理.txt',
    '03': '03-奖惩与申诉.txt', '04': '04-宿舍管理.txt', '05': '05-学生资助.txt',
    '06': '06-共青团工作.txt', '07': '07-综合素质考评管理办法.txt',
    '08': '08-总则-德育学分实施办法.txt', '09': '09-总则-学生管理规定与行为准则.txt',
    '10': '10-总则-国家教育考试违规处理办法.txt', '11': '11-总则-高等学校学生行为准则.txt',
    '90': '90-对照-学生自编重点整理.txt',
}
_cache = {}
def norm(s):
    return re.sub(r'\s+', '', s)
def load(k):
    if k not in _cache:
        _cache[k] = norm(open(os.path.join(SRC, FILES[k]), encoding='utf-8').read())
    return _cache[k]

def check(quote, allow=('01','02','03','05','06','07','08')):
    """返回 (ok, hit_keys)"""
    hits = []
    q = norm(quote)
    for k in allow:
        if q in load(k):
            hits.append(k)
    return (bool(hits), hits)

# 禁止内容红线
FORBIDDEN = [
    '五维', '美育', '劳育', '智育分占', '结果为优秀者', '综测须达优秀',
    '扣5分/10/15/20', '综测优秀≥90', '综测优秀 ≥90', '降级制度', '16学分降级',
    '24学分试读', '绩点门槛1.60', '平均学分绩点未达1.60', '旷课14天', '连续旷课14天',
    '第五星级标准', '五星级寝室标准为',
]

def main():
    files = sys.argv[1:]
    if not files:
        files = sorted(glob.glob(os.path.join(os.path.dirname(__file__), '..', 'cards', '*.md')))
    bad = 0
    for p in files:
        txt = open(p, encoding='utf-8').read()
        name = os.path.basename(p)
        # 段数
        secs = re.findall(r'(?m)^## (R|I|A1|A2|E|B) \|', txt)
        if secs != ['R','I','A1','A2','E','B']:
            print(f'[SECT] {name}: 段序异常 {secs}'); bad += 1
        # frontmatter
        for k in ('id:','slug:','destination:','name:'):
            if not re.search(r'(?m)^'+k, txt):
                print(f'[FM] {name}: 缺 {k}'); bad += 1
        # 禁止内容
        for f in FORBIDDEN:
            if f in txt:
                print(f'[BAN] {name}: 命中禁止内容「{f}」'); bad += 1
        # R 段逐句核对
        m = re.search(r'(?ms)^## R \| Reading（原文）\n(.*?)(?=^## I \|)', txt)
        if not m:
            print(f'[R] {name}: 未找到 R 段'); bad += 1
        else:
            body = m.group(1)
            for seg in body.split('／'):
                seg = seg.strip().lstrip('-').strip()
                seg = re.sub(r'`[^`]*`', '', seg)
                seg = seg.replace('**', '').strip()
                if not seg or seg.startswith('#'):
                    continue
                # 拆掉 【】注释与 ellipsis
                parts = [s for s in re.split(r'…+|\[\[|\]\]', seg) if len(s.strip()) > 6]
                for s in parts:
                    s2 = s.strip()
                    if len(s2) < 7:
                        continue
                    ok, hits = check(s2)
                    if not ok:
                        print(f'[QUOTE] {name}: 未命中 -> {s2[:60]}')
                        bad += 1
            # 字数
            raw = norm(re.sub(r'`[^`]*`', '', body))
            if len(raw) > 150:
                print(f'[LEN] {name}: R 段 {len(raw)} 字 > 150'); bad += 1
    print(f'--- 检查 {len(files)} 个文件，问题 {bad} 处 ---')

if __name__ == '__main__':
    main()